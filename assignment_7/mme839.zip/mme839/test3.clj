
(load-file "physics.clj")
(load-files)
(gramcom grammar)

(println "Question 1: ")
(phys '(How many m is 1 km))
(println)

(println "Question 2: ")
(phys '(How many cm is 10 in))
(println)

(println "Question 3: ")
(phys '(How many nm is 72 mm))
(println)

(println "Question 4: ")
(phys '(How many inches is 2 km))
(println)

(println "Question 5: ")
(phys '(How many nm is 15 cm ?))
(println)
