; load files for physics example                  28 Nov 18

; (load-file "cs378/physics.clj")
; (load-files)
; (gramcom grammar)
; (phys '(what is the area of a circle with radius = 2))
; 

(defn load-files []
(load-file "cs378.clj")
(load-file "asg1.clj")
(load-file "asg2.clj")
(load-file "patm.clj")
(load-file "pats.clj")
(load-file "asg3.clj")
(load-file "atn.clj")
(load-file "gramcom.clj")
(load-file "physgram.clj")
)
